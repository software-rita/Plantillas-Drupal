<?php

/**
 * @file
 * Post update functions for Gin Toolbar.
 */

/**
 * Please update Gin to version 8.x-3.x-alpha32+ for new settings.
 */
function gin_toolbar_post_update_update_gin_alpha32() {
  // Empty update to cause a cache rebuild.
}

/**
 * Fixes template discovery.
 */
function gin_toolbar_post_update_gin_toolbar_beta19() {
  // Empty update to cause a cache rebuild.
}

/**
 * Gin facelift update.
 */
function gin_toolbar_post_update_gin_toolbar_beta21() {
  // Empty update to cause a cache rebuild.
}

/**
 * Requires Gin Admin Theme Beta 2 or later.
 */
function gin_toolbar_post_update_gin_toolbar_beta22() {
  // Empty update to cause a cache rebuild.
}
